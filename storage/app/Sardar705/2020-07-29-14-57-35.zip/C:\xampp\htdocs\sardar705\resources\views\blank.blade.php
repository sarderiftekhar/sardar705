@extends('layouts.body')
@section('content')
      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
          <div class="row ">
               <h1>A blank page</h1>
          </div>
        </section>
      </div>
@stop

 